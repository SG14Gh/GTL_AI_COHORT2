## intent:ask_builder
- Who built you?

## intent:ask_weather
- What's the weather like?
- What's the weather like?

## intent:ask_whatismyname
- What's your name?

## intent:enter_data
- tell me a joke

## intent:goodbye
- Bye

## intent:greet
- Hi
- hi

## intent:howwereyoubuilt
- Who made you?
- how were you built?
