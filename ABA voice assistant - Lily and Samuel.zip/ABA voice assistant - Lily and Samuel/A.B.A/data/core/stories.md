## thank
* thank
    - utter_noworries
    - utter_anything_else

## bye
* bye
    - utter_bye

## greet
* greet OR enter_data{"name": "akela"}
    - utter_greet

<!-- ## sales
* greet
    - utter_greet
* contact_sales
    - utter_moreinformation
    - utter_ask_jobfunction
* enter_data{"jobfunction": "Product Manager"}
    - utter_store_job
    - slot{"job_function": "Product Manager"}
    - utter_ask_usecase
* enter_data    
    - utter_store_usecase
    - slot{"use_case": "bots"}
    - utter_thank_usecase
    - utter_ask_budget
* enter_data{"number": "100"} OR enter_data{"amount-of-money": "100k"} OR enter_data{"number": "100", "amount-of-money": "100"}
    - utter_store_budget
    - slot{"budget": "100k"}
    - utter_sales_contact
    - utter_ask_name
* enter_data{"name": "Max Meier"}
    - utter_store_name
    - slot{"person_name": "Max Meier"}
    - utter_ask_company
* enter_data{"company": "Allianz"}
    - utter_store_company
    - slot{"company_name": "Allianz"}
    - utter_ask_businessmail
* enter_data{"email": "maxmeier@firma.de"} OR enter_data{"number":"1"}
    - utter_store_email
    - slot{"email": "maxmeier@firma.de"}
    - utter_store_sales_info
    - slot{"data_stored": true}
    - utter_confirm_salesrequest
    - utter_ask_feedback
* feedback{"feedback_value": "positive"}
    - slot{"feedback_value": "positive"}
    - utter_great
    - utter_anything_else
 -->

<!-- ## shoe
* greet
    - utter_greet
* shoe_search
    - utter_shoe_type
* inform{"shoe_type":"adidas"}
    - action_shoe_search
    - utter_approve
* affirm+colors
    - utter_shoe_colors
* affirm+sizes
    - utter_shoe_sizes
* thank
  - utter_thank
* goodbye
  - utter_goodbye

## Suggestion path 2
* greet
  - utter_greet
* shoe_search{"shoe_type":"nike"}
  - action_shoe_search
  - utter_approve
* affirm+sizes
  - utter_shoe_sizes
* thank
  - utter_happy_reading
* goodbye
  - utter_goodbye

## Suggestion path 9
* greet
  - utter_greet
* shoe_search{"shoe_type":"physics"}
  - action_shoe_search
  - utter_approve
* affirm
  - utter_yes
* price
  - utter_shoe_price
* thank
  - utter_thank
* goodbye
  -utter_goodbye 

## Suggestion path 8
* greet
  - utter_greet
* shoe_search
  - utter_what_type
* inform{"shoe_type":"timberland"}
  - action_shoe_search
  - utter_approve
* affirm+prices
  - utter_shoe_price
* thank
  - utter_thank
* goodbye
  -utter_goodbye   
 -->
## chitchat
* ask_weather OR ask_builder OR ask_howdoing OR ask_whoisit OR ask_whatisrasa OR ask_isbot OR ask_howold OR ask_languagesbot OR ask_restaurant OR ask_time OR ask_wherefrom OR ask_whoami OR handleinsult OR nicetomeeyou OR telljoke OR ask_whatismyname OR howwereyoubuilt OR ask_whatspossible
    - action_chitchat

## deny ask_whatspossible
* ask_whatspossible
    - action_chitchat
* deny
    - utter_nohelp

## more chitchat
* greet
    - utter_greet
* ask_weather OR ask_builder OR ask_howdoing OR ask_whoisit OR ask_whatisrasa OR ask_isbot OR ask_howold OR ask_languagesbot OR ask_restaurant OR ask_time OR ask_wherefrom OR ask_whoami OR handleinsult OR nicetomeeyou OR telljoke OR ask_whatismyname OR howwereyoubuilt
    - action_chitchat
* ask_weather OR ask_builder OR ask_howdoing OR ask_whoisit OR ask_whatisrasa OR ask_isbot OR ask_howold OR ask_languagesbot OR ask_restaurant OR ask_time OR ask_wherefrom OR ask_whoami OR handleinsult OR nicetomeeyou OR telljoke OR ask_whatismyname OR howwereyoubuilt
    - action_chitchat

## ask_whatspossible
* greet
    - utter_greet
* ask_whatspossible
    - action_chitchat

## ask_whatspossible more
* greet
    - utter_greet
* ask_whatspossible
    - action_chitchat
* ask_whatspossible
    - action_chitchat
 


