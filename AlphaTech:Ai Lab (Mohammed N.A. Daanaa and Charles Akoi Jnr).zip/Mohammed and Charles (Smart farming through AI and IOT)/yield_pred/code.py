from keras.models import Sequential
from keras.models import *
from sklearn.model_selection import train_test_split
import numpy as np
import tensorflow as tf
import keras
from keras import models
from keras.layers import Activation, Dense
import pandas as pd
from keras.optimizers import Adam
from tpot import TPOTRegressor
import tpot


#seed = 10
#np.random.seed(seed)

'''
dataset = np.loadtxt('my_dat.csv', delimiter=',', skiprows=1)


X = dataset[:,0:4].values
y = dataset[:,[5]].values
'''


datasets = pd.read_csv('headbrain.csv', skiprows=1,delimiter=",")


#X = datasets.iloc[:,[1,2,3]].values
#area = datasets.iloc[:,[7]].values
#y = datasets.iloc[:,[5]].values
