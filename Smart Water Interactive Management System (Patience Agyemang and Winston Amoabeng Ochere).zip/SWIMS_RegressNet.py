# Importing requires Libraries
import pandas as pd
#import os
import numpy as np
import tensorflow as tf
from sklearn.model_selection import train_test_split,GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn import metrics
from sklearn.metrics import r2_score
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import Dropout
from keras.optimizers import Adam
#from keras.layers import Flatten
#from keras.layers import LSTM
from matplotlib import pyplot as plt
from keras.callbacks import EarlyStopping

# Reading from our dataset
data=pd.read_csv('C:/Users/Nana Amoabeng/Desktop/Water project/1Datasets/New_data_with_seconds.csv')

# Selecting our X and Y values from the dataset
X=data.iloc[:,6:8].values
y=data['Volume in gallons'].values

# Transforms our features 
X = StandardScaler().fit_transform(X)

X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.2,random_state=None)

# Defines "deep" model and its structure
model = Sequential()
model.add(Dense(13, input_shape=(2,), activation='relu'))
model.add(Dense(13, activation='relu'))
model.add(Dropout(0.2))
model.add(Dense(13, activation='relu'))
model.add(Dense(13, activation='relu'))
model.add(Dropout(0.2))
model.add(Dense(13, activation='relu'))
model.add(Dense(1,))
model.compile(Adam(lr=0.0003), 'mean_squared_error')

# Pass several parameters to 'EarlyStopping' function and assigns it to 'earlystopper'
earlystopper = EarlyStopping(monitor='val_loss', min_delta=0, patience=15, verbose=1, mode='auto')

# Fits model over 7 iterations with 'earlystopper' callback, and assigns it to history
history = model.fit(X_train, y_train, epochs = 7, validation_split = 0.2,shuffle = True, verbose = 1, 
                    callbacks = [earlystopper])

# Plots 'history'
history_dict=history.history
loss_values = history_dict['loss']
val_loss_values=history_dict['val_loss']
plt.plot(loss_values,'b',label='training loss')
plt.plot(val_loss_values,'r',label='training loss val')

# Runs model with its current weights on the training and testing data
y_train_pred = model.predict(X_train)
y_test_pred = model.predict(X_test)

# Calculates and prints r2 score of training and testing data
print("The R2 score on the Train set is:\t{:0.3f}".format(r2_score(y_train, y_train_pred)))
print("The R2 score on the Test set is:\t{:0.3f}".format(r2_score(y_test, y_test_pred)))

# Saving the model
model.save('predReg.h5')